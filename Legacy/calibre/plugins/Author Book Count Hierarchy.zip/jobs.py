from __future__ import (unicode_literals, division, absolute_import,
                        print_function)
__license__   = 'GPL v3'
__copyright__ = '2014,2015 DaltonST <DaltonShiTzu@outlook.com>'
__docformat__ = 'restructuredtext en'

import os, sys
from calibre.gui2.threaded_jobs import ThreadedJob, BaseJob
import traceback, cStringIO
from functools import partial
from threading import RLock
from threading import Thread, RLock, Event
from Queue import Empty, Queue
from calibre.utils.ipc.job import BaseJob
from Queue import Queue
from calibre.utils.logging import Log, GUILog

from calibre_plugins.author_book_count_hierarchy.main import Create_ABC_Hierarchy

# ------------------------------------------------------------------------------
#              Function to perform author book count using ThreadedJob
# ------------------------------------------------------------------------------

def start_abc_hierarchy_threaded(self, my_gui, my_guidb, callback):   # <<<==called from  ui.py

    self.gui = my_gui

    try:
        print("start_abc_hierarchy_threaded: ", my_guidb.library_path)
    except:
        pass

    job = ThreadedJob('author book count hierarchy plugin','Author Book Count Hierarchy',Create_ABC_Hierarchy,(self, my_guidb), {}, callback)
    self.gui.job_manager.run_threaded_job(job)
    self.gui.status_bar.show_message(_('This ABC job will update every book in your library'), 5000)


#END of jobs.py
