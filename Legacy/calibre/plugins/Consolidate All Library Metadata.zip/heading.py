# -*- coding: utf-8 -*-
from __future__ import (unicode_literals, division, absolute_import, print_function)
__license__   = 'GPL v3'
__copyright__ = '2015, DaltonST <DaltonShiTzu@outlook.com>'

__my_version__ = "1.0.0"

#------------------------------------------------------------------------------------------------------
def log_heading_common(log,s1,s2,s3,s4,s5):

    import time
    localtime = time.asctime( time.localtime(time.time()) )
    log(localtime)

    import platform
    log("Python: " + platform.system() + "   " + platform.python_implementation() + "   " + platform.python_version())

    if s1:
        if "00" in s1:
            s1 = str(s1.replace("00",".",2))
        log(s1)       #usually SQLite version

    if s2:              #usually PRAGMA statement
        if str(s2) == str("") :
            s2 = ""
            log(s2)
            log(" ")
            log("═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════")
        else:
            log(s2)
            log(" ")

    if s3:
        log(s3)        #usually "Beginning ...."

    if s4:
        log(s4)        #optional

    if s5:
        log(s5)        #optional

    log("═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════")

#END heading.py