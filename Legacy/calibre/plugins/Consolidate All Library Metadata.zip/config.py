# -*- coding: utf-8 -*-
from __future__ import (unicode_literals, division, absolute_import, print_function)
__license__   = 'GPL v3'
__copyright__ = '2015,2016,2017 DaltonST <DaltonShiTzu@outlook.com>'

__my_version__ = "2.0.30"  # Technical changes for Calibre 3.0.0 compatibility. Calibre Release 3.0.0 deprecated the use of calibredb while the GUI is also running

from PyQt5.Qt import (Qt, QDialog, QLabel, QVBoxLayout, QHBoxLayout, QFormLayout, QWidget, QPushButton,
        QGridLayout, pyqtSignal, QDialogButtonBox, QScrollArea, QFont, QPalette, QColor, QCheckBox,
        QTabWidget, QIcon, QToolButton, QSplitter, QGroupBox, QSpacerItem, QLineEdit,QSpinBox,
        QSizePolicy, QFrame, QSize, QKeySequence, QMenu, QShortcut, QMargins)

from calibre.utils.config import JSONConfig

# This is where all preferences for this plugin are stored
prefs = JSONConfig('plugins/Consolidate All Library Metadata')

# Set defaults

prefs.defaults['LIBRARY_PATH_03'] = unicode("")
prefs.defaults['LIBRARY_PATH_04'] = unicode("")
prefs.defaults['LIBRARY_PATH_05'] = unicode("")
prefs.defaults['LIBRARY_PATH_06'] = unicode("")
prefs.defaults['LIBRARY_PATH_07'] = unicode("")
prefs.defaults['LIBRARY_PATH_08'] = unicode("")
prefs.defaults['LIBRARY_PATH_09'] = unicode("")

prefs.defaults['LIBRARY_PATH_10'] = unicode("")
prefs.defaults['LIBRARY_PATH_11'] = unicode("")
prefs.defaults['LIBRARY_PATH_12'] = unicode("")
prefs.defaults['LIBRARY_PATH_13'] = unicode("")
prefs.defaults['LIBRARY_PATH_14'] = unicode("")
prefs.defaults['LIBRARY_PATH_15'] = unicode("")
prefs.defaults['LIBRARY_PATH_16'] = unicode("")
prefs.defaults['LIBRARY_PATH_17'] = unicode("")
prefs.defaults['LIBRARY_PATH_18'] = unicode("")
prefs.defaults['LIBRARY_PATH_19'] = unicode("")

prefs.defaults['LIBRARY_PATH_20'] = unicode("")
prefs.defaults['LIBRARY_PATH_21'] = unicode("")
prefs.defaults['LIBRARY_PATH_22'] = unicode("")
prefs.defaults['LIBRARY_PATH_23'] = unicode("")
prefs.defaults['LIBRARY_PATH_24'] = unicode("")
prefs.defaults['LIBRARY_PATH_25'] = unicode("")
prefs.defaults['LIBRARY_PATH_26'] = unicode("")
prefs.defaults['LIBRARY_PATH_27'] = unicode("")
prefs.defaults['LIBRARY_PATH_28'] = unicode("")
prefs.defaults['LIBRARY_PATH_29'] = unicode("")

prefs.defaults['LIBRARY_PATH_30'] = unicode("")
prefs.defaults['LIBRARY_PATH_31'] = unicode("")
prefs.defaults['LIBRARY_PATH_32'] = unicode("")
prefs.defaults['LIBRARY_PATH_33'] = unicode("")
prefs.defaults['LIBRARY_PATH_34'] = unicode("")
prefs.defaults['LIBRARY_PATH_35'] = unicode("")
prefs.defaults['LIBRARY_PATH_36'] = unicode("")
prefs.defaults['LIBRARY_PATH_37'] = unicode("")
prefs.defaults['LIBRARY_PATH_38'] = unicode("")
prefs.defaults['LIBRARY_PATH_39'] = unicode("")

prefs.defaults['LIBRARY_PATH_40'] = unicode("")
prefs.defaults['LIBRARY_PATH_41'] = unicode("")
prefs.defaults['LIBRARY_PATH_42'] = unicode("")
prefs.defaults['LIBRARY_PATH_43'] = unicode("")
prefs.defaults['LIBRARY_PATH_44'] = unicode("")
prefs.defaults['LIBRARY_PATH_45'] = unicode("")
prefs.defaults['LIBRARY_PATH_46'] = unicode("")
prefs.defaults['LIBRARY_PATH_47'] = unicode("")
prefs.defaults['LIBRARY_PATH_48'] = unicode("")
prefs.defaults['LIBRARY_PATH_49'] = unicode("")

prefs.defaults['LIBRARY_PATH_50'] = unicode("")
prefs.defaults['LIBRARY_PATH_51'] = unicode("")
prefs.defaults['LIBRARY_PATH_52'] = unicode("")

prefs.defaults['LIBRARY_PATH_03_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_04_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_05_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_06_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_07_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_08_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_09_IS_ACTIVE'] = unicode("False")

prefs.defaults['LIBRARY_PATH_10_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_11_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_12_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_13_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_14_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_15_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_16_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_17_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_18_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_19_IS_ACTIVE'] = unicode("False")

prefs.defaults['LIBRARY_PATH_20_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_21_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_22_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_23_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_24_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_25_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_26_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_27_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_28_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_29_IS_ACTIVE'] = unicode("False")

prefs.defaults['LIBRARY_PATH_30_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_31_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_32_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_33_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_34_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_35_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_36_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_37_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_38_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_39_IS_ACTIVE'] = unicode("False")

prefs.defaults['LIBRARY_PATH_40_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_41_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_42_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_43_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_44_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_45_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_46_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_47_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_48_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_49_IS_ACTIVE'] = unicode("False")

prefs.defaults['LIBRARY_PATH_50_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_51_IS_ACTIVE'] = unicode("False")
prefs.defaults['LIBRARY_PATH_52_IS_ACTIVE'] = unicode("False")

prefs.defaults['CALM_USER_STATUS'] = unicode('UNKNOWN')

prefs.defaults['CALM_TARGET_PARENT_DIRECTORY'] = unicode('ZZ:')
prefs.defaults['CALM_TARGET_DB_FULL_PATH'] = unicode('ZZ:')
prefs.defaults['CALM_TARGET_DB_GENERATING_NONCALM_LIBRARY_PATH'] = unicode('ZZ:||>>>||ZZ:')
prefs.defaults['CALM_TARGET_DB_LAST_CHOSEN_LIBRARY_DIRECTORY'] = unicode('ZZ:')

prefs.defaults['CALM_TARGET_DB_MUST_BE_REFRESHED'] = unicode("False")

prefs.defaults['CALM_DB_VERSION_METADATA_DB'] = unicode(2)

prefs.defaults['CALM_DB_VERSION_UPGRADE_SUPPRESS_INFO_DIALOGS'] = unicode("False")
prefs.defaults['CALM_DB_VERSION_UPGRADE_FORCE_UPGRADE'] = unicode("False")

prefs.defaults['CALM_DB_VERSION_METADATA_TOOLS_DB'] = unicode(2)

prefs.defaults['GUI_LAST_UPDATE_DATETIME_SOURCE'] = unicode("Last Saved:   ..NEVER...               Number of 'Checked' Libraries Saved: [0]")
prefs.defaults['GUI_NUMBER_SOURCE_LIBRARIES_LAST_SAVED'] = unicode(0)

prefs.defaults['GUI_LAST_UPDATE_DATETIME_TARGET'] = unicode('..NEVER...')

prefs.defaults['GUI_TARGET_DB_AGE_MESSAGE_LAST_DISPLAYED'] = unicode("2015-12-01")

prefs.defaults['GUI_LAST_CC_GENERATION_DATETIME_TARGET'] = unicode('...NEVER...')
prefs.defaults['GUI_LAST_CC_GENERATION_WAS_SUCCESSFUL'] =  unicode(0)
prefs.defaults['GUI_LAST_CC_GENERATION_NUMBER_LIBRARIES'] =  unicode(0)
prefs.defaults['GUI_LAST_CC_GENERATION_NO_LIBRARIES_TO_GENERATE'] = unicode("False")

prefs.defaults['CALM_LAST_CONSOLIDATION_JOB_DATETIME'] = unicode('...NEVER...')
prefs.defaults['CALM_LAST_CONSOLIDATION_TARGET_DB_FULL_PATH'] = unicode('ZZ:')
prefs.defaults['CALM_LAST_CONSOLIDATION_NUMBER_LIBRARIES'] =  unicode(0)
prefs.defaults['CALM_LAST_CONSOLIDATION_NUMBER_BOOKS'] =  unicode(0)

prefs.defaults['GUI_METADATA_TOOLS_LAST_SOURCES_DEFRAGMENT_DATETIME'] = unicode('...NEVER...')
prefs.defaults['GUI_METADATA_TOOLS_LAST_SOURCES_DEFRAGMENT_COUNT'] = unicode(0)

prefs.defaults['GUI_LAST_TAB_USED'] = unicode('0')

prefs.defaults['genre'] = unicode("#genre_calm")        # owned by the 'Derive Genres' job

prefs.defaults['CALM_MCS_INDEX_CONSOLIDATION'] = unicode("False")

class ConfigWidget(QWidget):

    def __init__(self):

        QWidget.__init__(self)

        self.layout_1 = QVBoxLayout()
        self.setLayout(self.layout_1)

        self.layout_1.setSpacing(0)
        self.layout_1.setContentsMargins(QMargins(0,0,0,0));

        self.paths_groupbox = QGroupBox('Preferences')
        self.layout_1.addWidget(self.paths_groupbox)

        self.paths_layout = QGridLayout()
        self.paths_groupbox.setLayout(self.paths_layout)

        font = QFont()

        font.setBold(False)
        font.setPointSize(10)

        self.label1 = QLabel()
        self.label1.setTextFormat(1)
        self.label1.setText("<center><font color='#0404B4'>               Please Customize Directly Within CALM             </font></center>")
        self.label1.setFont(font)
        self.paths_layout.addWidget(self.label1)

        self.resize(self.sizeHint())

    def save_settings(self):
        return
    def validate(self):
        return False

#END of config.py

