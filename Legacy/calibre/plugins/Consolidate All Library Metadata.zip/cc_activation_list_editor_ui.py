# -*- coding: utf-8 -*-

from PyQt5 import QtCore, QtGui, QtWidgets

__my_version__ = "2.0.3"

class Ui_CCActivationListEditor(object):
    def setupUi(self, CCActivationListEditor):
        CCActivationListEditor.setObjectName("CCActivationListEditor")
        CCActivationListEditor.resize(600, 600)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("config.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        CCActivationListEditor.setWindowIcon(icon)
        self.gridlayout = QtWidgets.QGridLayout(CCActivationListEditor)
        self.gridlayout.setObjectName("gridlayout")
        self.horizontalLayout_11 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_11.setObjectName("horizontalLayout_11")
        self.search_button = QtWidgets.QToolButton(CCActivationListEditor)
        self.search_button.setObjectName("search_button")
        self.gridlayout.addLayout(self.horizontalLayout_11, 0, 1, 1, 1)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.change_button = QtWidgets.QToolButton(CCActivationListEditor)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(I("edit_book.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.change_button.setIcon(icon1)
        self.change_button.setIconSize(QtCore.QSize(32, 32))
        self.change_button.setObjectName("change_button")
        self.verticalLayout_2.addWidget(self.change_button)
        #self.rename_button = QtWidgets.QToolButton(CCActivationListEditor)
        #~ icon2 = QtGui.QIcon()
        #~ icon2.addPixmap(QtGui.QPixmap(I("edit_input.png")), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        #self.rename_button.setIcon(icon2)
        #self.rename_button.setIconSize(QtCore.QSize(2, 2))
        #self.rename_button.setObjectName("rename_button")
        self.gridlayout.addLayout(self.verticalLayout_2, 1, 0, 1, 1)
        self.table = QtWidgets.QTableWidget(CCActivationListEditor)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        #~ self.table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection )
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setObjectName("table")
        self.table.setColumnCount(0)
        self.table.setRowCount(0)
        self.gridlayout.addWidget(self.table, 1, 1, 1, 1)
        self.buttonBox = QtWidgets.QDialogButtonBox(CCActivationListEditor)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName("buttonBox")
        self.gridlayout.addWidget(self.buttonBox, 3, 0, 1, 2)

        self.retranslateUi(CCActivationListEditor)
        self.buttonBox.accepted.connect(CCActivationListEditor.accept)
        self.buttonBox.rejected.connect(CCActivationListEditor.reject)
        QtCore.QMetaObject.connectSlotsByName(CCActivationListEditor)

    def retranslateUi(self, CCActivationListEditor):

        CCActivationListEditor.setWindowTitle(_("Selectively Activate/Deactivate Source Custom Columns for Generation & Consolidation"))
        #~ self.change_button.setToolTip(_("..."))
        self.change_button.setToolTip(_("Click this button to add the Selected Row to the List of Changes to be made once you Save and Exit."))
        self.change_button.setText(_("Save"))

