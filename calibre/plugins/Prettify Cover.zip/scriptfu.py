#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
from __future__ import (unicode_literals, absolute_import)
from sys import platform as _platform
import os, subprocess

__license__   = 'GPL v3'
__copyright__ = '2016, Michael Dinkelaker, <michael.dinkelaker@gmail.com>'
__docformat__ = 'restructuredtext en'

def gimp_fu_it(filename, opt0="10", opt1="2"):

	cmd = "1"
    bin = "1"
    result = False

	args = "--stack-trace-mode=never -d -f -s -n -i -b '(let* ((run-mode 1) "
    args += '(samplingRadiusParam '+opt0+') (orderParam '+opt1+') (filename "'+filename+'")'
    args += """(image (car (gimp-file-load run-mode filename filename) )) 
               (drawable (car (gimp-image-get-active-layer image)  )))
                (gimp-image-undo-disable image)                
          (python-fu-heal-transparency run-mode image drawable samplingRadiusParam orderParam)
          (gimp-file-save run-mode image drawable filename "content-aware")
          (gimp-quit 1)
         )'"""

    # LINUX
    if _platform == "linux" or _platform == "linux2":

        binaries = [    "/usr/bin/gimp-console",        # usually there is a symbolic link to the current version
                        "/usr/bin/gimp-console-2.10",   # trying for specific version
                        "/usr/bin/gimp-console-2.9",
                        "/usr/bin/gimp-console-2.8",
                        "/usr/bin/gimp-console-2.7",
                        "/usr/bin/gimp-console-2.6"
                    ]

        bin = find_binary(binaries)
        if bin != "":
		    cmd = bin +" "+args
            try:
                os.system(cmd)
                result = True
            except:
                result = False
        else:
            result = False

    # WINDOWS
    elif _platform == "win32":

        path = 'C:\\Program Files\\GIMP 2\\bin\\'
        binaries = [    path+'gimp-console-2.8.exe',
                        path+'gimp-console-2.9.exe',
                        path+'gimp-console-2.10.exe',
                        path+'gimp-console-2.7.exe',
                        path+'gimp-console-2.6.exe',
                        path+'gimp-console.exe'
            ]
        bin = find_binary(binaries)
        if bin != "":
            startupinfo = subprocess.STARTUPINFO()
            args = args.replace("\n", " ")
            cond = False
            while not cond:
                new = args.replace("  ", " ")
                cond = (args == new)
                args = new

            args = args.replace('\\', '/') 		#gimp-win, or cmd doesn't like backslashes
            args = args.replace('"', '\\"') 	#gimp-win, or cmd doesn't like double quotes within double quotes [because]
            args = args.replace("'", '"') 		#gimp-win, or cmd doesn't like single quotes
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE

            cmd = bin +" "+args
            try:
                subprocess.call(cmd, startupinfo=startupinfo)
                result = True
            except:
                result = False
        else:
            result = False

    # MAC
    elif _platform == "darwin":
        # MAC OS X
        #bin = "/usr/bin/gimp"
        result = False

    return result


def is_exe(fpath):
        return os.path.isfile(fpath) and os.access(fpath, os.X_OK)

def run_gimp(cmdline):
    result = False
    if _platform == "linux" or _platform == "linux2":
        try:
            os.system(cmdline)
            result = True
        except:
            result = False

    elif _platform == "win32":
        cmdline = cmdline .replace('\\', '/')  # gimp-win, or cmd doesn't like backslashes
        cmdline = cmdline .replace('"', '\\"')  # gimp-win, or cmd doesn't like double quotes within double quotes [because]
        cmdline = cmdline .replace("'", '"')  # gimp-win, or cmd doesn't like single quotes

        #  fix german Umlaute on win
        import locale
        os_encoding = locale.getpreferredencoding()
        cmdline = cmdline.encode(os_encoding)
        try:
            FNULL = open(os.devnull, 'w')
            retcode = subprocess.call(cmdline, stdout=FNULL, stderr=subprocess.STDOUT)
            result = True
        except:
            result = False
    return result


def find_gimp():
    # check if gimp is installed
    if _platform == "linux" or _platform == "linux2":

        binaries = [    "/usr/bin/gimp",        # usually there is a symbolic link to the current version
        ]

    # WINDOWS
    elif _platform == "win32":

        path = 'C:\\Program Files\\GIMP 2\\bin\\'
        binaries = [path + 'gimp-2.8.exe',
                    path + 'gimp-2.9.exe',
                    path + 'gimp-2.10.exe',
                    path + 'gimp-2.7.exe',
                    path + 'gimp-2.6.exe',
        ]

    else:
        return ""

    return find_binary(binaries)

def find_binary(binaries):
        bin = ""
        for binary in binaries:
            if is_exe(binary):
              bin = binary
               # break?
        return bin