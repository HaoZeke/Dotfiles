#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import unicode_literals
from calibre.gui2 import sanitize_env_vars
from calibre_plugins.prettify_cover import __version__

import os
from sys import platform as _platform
import subprocess


__license__ = "GPL v3"
__copyright__ = "Copyright 2015-2017"
__author__ = "Michael Dinkelaker"
__email__ = "michael.dinkelaker@gmail.com"
__docformat__ = "restructuredtext en"


# detect gimp installed to non-default location
# def doit():
#     print(os.environ)
#     cmd = "reg export HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\" \
#           "CurrentVersion\\Uninstall\\GIMP-2_is1 " + \
#           os.environ['TEMP']+ "\\gimp.txt"
#     
#     startupinfo = subprocess.STARTUPINFO()
#     startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
#     startupinfo.wShowWindow = subprocess.SW_HIDE
#     
#     try:
#         subprocess.call(cmd, startupinfo=startupinfo)            
#         result = True
#     except Exception:
#         result = False
#         
#         print("result: win reg thing: "+str(result))
#     return result


def heal_cover(filename, opt0="10", opt1="2"):
    args = "--stack-trace-mode=never -d -f -s -n -i -b '(let* ((run-mode 1) "
    args += '(samplingRadiusParam ' + opt0 + ') (orderParam ' + opt1 + ') ' \
        '(filename "' + filename + '")'
    args += """(image (car (gimp-file-load run-mode filename filename) ))
               (drawable (car (gimp-image-get-active-layer image)  )))
                (gimp-image-undo-disable image)
          (python-fu-heal-transparency run-mode image drawable
          samplingRadiusParam orderParam)
          (gimp-file-save run-mode image drawable filename "content-aware")
          (gimp-quit 0)
         )'"""
    return gimp_fu_it(args, True)


def gimp_ng_cover(filename):
    # (elsamuko-national-geographic run-mode image drawable
    # value value value value value toggle option)
    # http://registry.gimp.org/node/9592    

    # args = "--stack-trace-mode=never -n -i -b "
    args = "-n -i -b "
    args += "\"(elsamuko-national-geographic-batch "
    
    # v0.9.12: special treatment for windows console
    if _platform == "win32":        
        filename = filename.replace('/', '\\')
        filename = filename.replace('\\', '\\\\')
    
    args += '\\"' + filename + '\\"'        
    args += ' 60 1 60 25 0.4 1 0)" -b "(gimp-quit 0)"'
    return gimp_fu_it(args)


def gimp_fu_it(args, win_replace=False):
    cmd = "1"
    prg = "1"
    result = False

    # linux
    if _platform == "linux" or _platform == "linux2":
        binaries = [
            "/usr/bin/gimp-console",
            "/usr/bin/gimp-console-2.10",
            "/usr/bin/gimp-console-2.9",
            "/usr/bin/gimp-console-2.8",
            "/usr/bin/gimp-console-2.7",
            "/usr/bin/gimp-console-2.6",
        ]

        prg = find_binary(binaries)
        if prg != "":
            cmd = prg + " " + args
            try:
                with sanitize_env_vars():
                    os.system(cmd)
                    result = True
            except Exception:
                result = False
        else:
            result = False

    # windows
    elif _platform == "win32":
        path = 'C:\\Program Files\\GIMP 2\\bin\\'
        binaries = [
            path + 'gimp-console-2.8.exe',
            path + 'gimp-console-2.9.exe',
            path + 'gimp-console-2.10.exe',
            path + 'gimp-console-2.7.exe',
            path + 'gimp-console-2.6.exe',
            path + 'gimp-console.exe',
        ]

        prg = find_binary(binaries)
        if prg != "":
            startupinfo = subprocess.STARTUPINFO()
            args = args.replace("\n", " ")
            cond = False
            while not cond:
                new = args.replace("  ", " ")
                cond = (args == new)
                args = new

            if win_replace:
                args = args.replace('\\', '/')
                args = args.replace('"', '\\"')
                args = args.replace("'", '"')
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE

            cmd = prg + " " + args

            # DEBUG
            print(cmd)
            try:
                with sanitize_env_vars():
                    subprocess.call(cmd, startupinfo=startupinfo)
                    result = True
            except Exception:
                result = False
        else:
            result = False

    # TODO: MAC. elif _platform == "darwin":
    return result


def is_exe(fpath):
    return os.path.isfile(fpath) and os.access(fpath, os.X_OK)


def run_gimp(cmdline):
    result = False
    if _platform == "linux" or _platform == "linux2":
        try:
            with sanitize_env_vars():
                os.system(cmdline)
                result = True
        except Exception:
            result = False

    elif _platform == "win32":
        """
        gimp-win, or cmd doesn't like backslashes
        gimp-win, or cmd doesn't like double quotes within double quotes
        gimp-win, or cmd doesn't like single quotes
        """
        cmdline = cmdline.replace('\\', '/')
        cmdline = cmdline.replace('"', '\\"')
        cmdline = cmdline.replace("'", '"')

        #  fix encoding on
        import locale
        os_encoding = locale.getpreferredencoding()
        cmdline = cmdline.encode(os_encoding)
        # print(cmdline)
        # exit(0)
        try:
            with sanitize_env_vars():
                devnull = open(os.devnull, 'w')
                subprocess.call(cmdline, stdout=devnull, stderr=subprocess.STDOUT)
                result = True
        except Exception:
            result = False
    return result


def find_gimp():
    # check if gimp is installed
    if _platform == "linux" or _platform == "linux2":
        binaries = ["/usr/bin/gimp"]

    # windows
    elif _platform == "win32":
        path = 'C:\\Program Files\\GIMP 2\\bin\\'
        binaries = [
            path + 'gimp-2.8.exe',
            path + 'gimp-2.9.exe',
            path + 'gimp-2.10.exe',
            path + 'gimp-2.7.exe',
            path + 'gimp-2.6.exe',
        ]
    else:
        return ""
    return find_binary(binaries)


def find_binary(binaries):
    prg = ""
    for binary in binaries:
        if is_exe(binary):
            prg = binary
            break
    return prg


# XXX: unused code
# def find_plugin_heal_trans():
#     """ Lets check if the "Heal Transparency"
#
#     - Resynthesizer plugins is available
#     :returns: True/False
#     """
#     path = ""
#     if _platform == "linux" or _platform == "linux2":
#         path = "/usr/lib/gimp/2.0/plug-ins/"
#
#     elif _platform == "win":
#         path = ""
#
#     path += "plugin-heal-transparency.py"
#
#     if len(path) > 0:
#         return os.path.exists(path)
#     return False


def find_plugin_ng():
    """ Lets check for gimp plugins

    - National Geographic
    Book covers optimized with the N.G. plugins
    look better on 16-color black & white e-reader.
    For now it's just this one.

    :returns: True/False
    """
    path = ""
    if _platform == "linux" or _platform == "linux2":
        path = "/usr/share/gimp/2.0/scripts/"
    elif _platform == "win32":        
        path = "C:\\Program Files\\GIMP 2\\share\\gimp\\2.0\\scripts\\"        

    path += "elsamuko-national-geographic-batch.scm"

    if len(path) > 0:
        return os.path.exists(path)

    return False
